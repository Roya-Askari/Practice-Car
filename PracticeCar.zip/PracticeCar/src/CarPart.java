
public class CarPart implements Functional{
public static int condition;//represents the remaining durability of the part (starts at 100, goes down to 0 when the part is broken)
	
	public void status( int condition ) {// print condition of the part to the console
	
		
		
		if(condition==100)
			System.out.println("The part is new."); 
		else if(condition>70 && condition<100){
			System.out.println("the part is in very good condition.");
		}else if(condition>40 && condition<70){
			System.out.println("the part is in fair condition.");
		}else if(condition>1 && condition<40)
			System.out.println("The part should be changed");
		else if(condition==0)
			System.out.println("the part is broken, change immidiately!");
		
	}
	
	
	
	@Override
	public void function() {
		// TODO Auto-generated method stub
		System.out.println("this part shows all the functions");
		
	}




	
	
}
