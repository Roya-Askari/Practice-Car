import java.util.Scanner;

public class Wheels extends CarPart {
	private int noWheels;
	
	public int getNoWheels() {
		return noWheels;
	}

	public void setNoWheels(int noWheels) {
		this.noWheels = noWheels;
	}

	@Override
	public String toString() {
		return "Wheels [Wheels=" + noWheels + "]";
	}


	Scanner scanner= new Scanner(System.in);

	
    //a method that prints the condition of the part to the console.
	
	public void conditionOfWheels() {
		
		System.out.println("Please enter the condition(0-100)");
		condition=scanner.nextInt();
		status(condition);
		
		
	}

	@Override
	public void function() {
		System.out.println("Please entere the numbere of wheels: ");
		 
		setNoWheels(scanner.nextInt());
		  System.out.println(" the car has "+getNoWheels() + "wheels.");
		  conditionOfWheels();
}
}
