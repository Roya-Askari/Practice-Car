import java.util.Scanner;

public class FuelTank extends CarPart {
	
	private int fuelLevel ;
	
	//getter
	public int getFuelLevel() {
		return fuelLevel;
	}
	//setter
	public void setFuelLevel(int fuelLevel) {
		this.fuelLevel = fuelLevel;
	}
   

	Scanner scan= new Scanner(System.in);
    

	
	public void conditionOfFuelTank() {
		System.out.println("what is the fuelTank condition: ");
	
		condition=scan.nextInt();
		status(condition);
		
	}

	@Override
	public void function() {
		System.out.println("what is the fuel Level?");
		setFuelLevel(scan.nextInt());
		System.out.println("the fuel level of car is"+getFuelLevel()+ ".");
		conditionOfFuelTank();
	}

	@Override
	public String toString() {
		return "FuelTank [fuelLevel=" + fuelLevel +"]";
	}
}
