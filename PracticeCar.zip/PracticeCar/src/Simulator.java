
public class Simulator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car car= new Car();
		car.run( );
		
		
		
		
	}

}
