import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class Car {
	 //CarPart[] objCarP = new CarPart[1];
	
	
	 List<CarPart> cpList=new ArrayList<CarPart>();
	CarPart engine;
	CarPart wheels;
	CarPart fuelTank;
     CarPart cp= new CarPart();

   /*	Make sure that your Car class creates an instance of each CarPart subclass,
   	as part of its constructor. These instances should be added to a collection 
   	of CarPart reference variables.*/
     
	public Car(){
		engine= new Engine();
		wheels=new Wheels();
		fuelTank= new FuelTank();
		
       
		cpList.add(engine);
		cpList.add(fuelTank);
		cpList.add(wheels);
		
		
	}
	
	
	// Iterate through the list
	
	public void run() {
		
		cp.function();
		engine.function();
		wheels.function();
		fuelTank.function();
		Iterator<CarPart> iterator= cpList.iterator();
		
		while(iterator.hasNext())
			System.out.println(iterator.next());
		
		
	
		}
	
	}
