import java.util.Scanner;

public class Engine extends CarPart  {
	
	 private int noCylander;
	
	
	public int getNoCylander() {
		return noCylander;
	}

	public void setNoCylander(int noCylander) {
		this.noCylander = noCylander;
	}

	Scanner scan=new Scanner(System.in);
	
	/*public Engine(int noCylander) {
		this.noCylander=noCylander;
	}
*/
	
	public void conditionofEngine() {
		
		System.out.println("How is the condition of engine between 0-100? ");
		condition=scan.nextInt();
		
		status(condition);
	}

	@Override
	public String toString() {
		return "Engine [noCylander=" + noCylander + "]";
	}

	@Override
	public void function() {
		// TODO Auto-generated method stub
		System.out.println("how many sylander the car has?");
		setNoCylander(scan.nextInt());
		System.out.println("the car has "+noCylander+ "Cylander.");
		conditionofEngine();
	}
	
}
